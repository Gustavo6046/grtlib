#include "Line.h"
using std::pair;

Line::Line(pair<Vector*, Vector*> _sides)
{
    sides = _sides;
    slope = (_sides.second->y - _sides.second->x) / (_sides.first->y - _sides.first->x);
}
