#include "RenderObj.h"


bool RenderObj::bIntersects(Ray* ray, double* dist)
{
    return false; // to prevent ghost shapes by rogue RenderObj's
}
