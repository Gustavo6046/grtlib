#ifndef TRIANGLE_H
#define TRIANGLE_H

#include "Line.h"
#include "Camera.h"
#include "Vector.h"
#include "Raymath.h"
#include "RenderObj.h"

#include <math.h>


extern "C" int intersect_triangle3(double orig[3], double dir[3],
			double vert0[3], double vert1[3], double vert2[3],
			double *t, double *u, double *v);

class Triangle :public RenderObj
{
    public:
        /** Default constructor */
        Triangle(Vector points[3], Vector color);

        std::vector< std::pair<Vector*, Vector*> > edges;
        Vector myColor;
        bool bIntersects(Ray* ray, double* dist);

    protected:
    private:
};

#endif // TRIANGLE_H
